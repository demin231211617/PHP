<?php
require_once("Point.php");

function getMidpoint(Point $point1, Point $point2): Point{
    $midPointX = ($point1 -> x + $point2-> x) /2;
    $midPointY = ($point1 -> y + $point2-> y) /2;

    $midPoint = new Point();

    $midPoint->x = $midPointX;
    $midPoint->y = $midPointY;

    return $midPoint;
}