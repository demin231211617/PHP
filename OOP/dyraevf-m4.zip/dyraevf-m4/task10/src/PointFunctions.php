<?php

namespace App;
use App\Point;

function dup(Point $point1): Point
{
    $point2 = new Point(); // Создаем новый объект точки
    $point2->x = $point1->x; // Присваиваем значения координат из исходной точки
    $point2->y = $point1->y;
    return $point2; // Возвращаем клонированную точку
}