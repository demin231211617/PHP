<?php

namespace App;

class Point{
    public float $x;
    public float $y;
}
