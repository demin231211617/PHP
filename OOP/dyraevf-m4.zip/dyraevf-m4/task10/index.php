<?php

namespace App;

require __DIR__ . "/vendor/autoload.php";

use function App\dup;
use App\Point;

$point1 = new Point();
$point1->x = 2;
$point1->y = 2;
$point2 = dup($point1);

$cleaner = explode("", $point2);

print_r($point1);
print("<br>");
print_r($point2);
