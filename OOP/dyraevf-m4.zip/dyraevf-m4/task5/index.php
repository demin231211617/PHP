<?php

function makeDecartPoint($x, $y)
{
    return [
        'x' => $x,
        'y' => $y
    ];
}

function getX($point)
{
    return $point['x'];
}

function getY($point)
{
    return $point['y'];
}


function getStartPoint($rectangle) {
    return $rectangle['startPoint'];
}

// Define the getWidth function
function getWidth($rectangle) {
    return $rectangle['width'];
}

// Define the getHeight function
function getHeight($rectangle) {
    return $rectangle['height'];
}

function getQuadrant($point)
{
    $x = getX($point);
    $y = getY($point);

    if ($x > 0 && $y > 0) {
        return 1;
    } elseif ($x < 0 && $y > 0) {
        return 2;
    } elseif ($x < 0 && $y < 0) {
        return 3;
    } elseif ($x > 0 && $y < 0) {
        return 4;
    }

    return null;
}



function containsOrigin($rectangle){
    $startPoint = getStartPoint($rectangle);
    $width = getWidth($rectangle);
    $height = getHeight($rectangle);

    $endPoint = makeDecartPoint(getX($startPoint) + $width, getY($startPoint) - $height);

    return getQuadrant($startPoint) === 2 && getQuadrant($endPoint) === 4;
}


function makeRectangle($point, $width, $height) {
    return [
        'startPoint' => $point,
        'width' => $width,
        'height' => $height,
    ];
}



$p = makeDecartPoint(0, 1);
$rectangle = makeRectangle($p, 4, 5);
print_r(getStartPoint($rectangle));
print "<br>";
print getWidth($rectangle);
print "<br>";
print getHeight($rectangle);
print "<br>";

$p2 = makeDecartPoint(-4, 3);
$rectangle2 = makeRectangle($p2, 5, 4);
print_r(getStartPoint($rectangle2));
print "<br>";
print getWidth($rectangle2);
print "<br>";
print getHeight($rectangle2);
print "<br>";

$p = makeDecartPoint(0, 1);
$rectangle = makeRectangle($p, 4, 5);
print_r(containsOrigin($rectangle)?"true":"false");
print "<br>";

$p2 = makeDecartPoint(-4, 3);
$rectangle2 = makeRectangle($p2, 5, 4);
print_r(containsOrigin($rectangle2)?"true":"false");
print "<br>";

$rectangle3 = makeRectangle($p2, 2, 2);
print_r(containsOrigin($rectangle3)?"true":"false");
print "<br>";

$rectangle4 = makeRectangle($p2, 5, 2);
print_r(containsOrigin($rectangle4)?"true":"false");
print "<br>";

$rectangle5 = makeRectangle($p2, 2, 4);
print_r(containsOrigin($rectangle5)?"true":"false");
print "<br>";

$rectangle6 = makeRectangle($p2, 4, 3);
print_r(containsOrigin($rectangle6)?"true":"false");