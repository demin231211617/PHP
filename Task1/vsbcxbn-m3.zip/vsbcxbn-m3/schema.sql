CREATE TABLE IF NOT EXISTS category(
    id int auto_increment primary key,
    name varchar(200) UNIQUE not null,
    code varchar(200) UNIQUE not null
);

CREATE TABLE IF NOT EXISTS user(
    id int auto_increment primary key,
    date_registration timestamp default CURRENT_TIMESTAMP,
    email varchar(200) not null unique,
    name varchar(200) not null,
    password varchar(200) not null,
    contacts varchar(200) not null
);

CREATE TABLE IF NOT EXISTS lot(
    id int auto_increment primary key,
    date_create timestamp default CURRENT_TIMESTAMP,
    name varchar(200) not null,
    description varchar(200),
    image varchar(200) not null,
    start_price int not null,
    date_finish int  not null,
    step_bid int  not null,
    author_id int not null,
    winner_id int,
    category_id int not null,
    foreign key (author_id) references user(id) on delete cascade,
    foreign key (winner_id) references user(id) on delete cascade,
    foreign key (category_id) references category(id) on delete cascade
);

CREATE TABLE IF NOT EXISTS bid(
    id int auto_increment primary key,
    date_create timestamp default CURRENT_TIMESTAMP,
    price int not null,
    user_id int not null,
    lot_id int not null,
    foreign key (user_id) references user(id) on delete cascade,
    foreign key (lot_id) references lot(id) on delete cascade
);