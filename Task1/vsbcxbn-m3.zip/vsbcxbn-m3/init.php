<?php

require_once('functions.php');

#инициализация переиенных
$page_title = 'Главная';
$is_auth = rand(0, 1);
$user_name = 'Дмитрий';

#константы для подключения к базе данных
const DATABASE_HOST = 'localhost';
const DATABASE_USERNAME = 'bkbddfiv';
const DATABASE_PASSWORD = 'jn2EbV';
const DATABASE_NAME = 'bkbddfiv_m3';

#подключение к базе данных
$mysql = mysqli_connect(DATABASE_HOST, DATABASE_USERNAME, DATABASE_PASSWORD, DATABASE_NAME);

#установка кодировки
#mysqli_set_charset($mysql, "utf8");

#проверка подключения
if(!$mysql) {
    print("Ошибка подключения: " . mysqli_connect_error());
}else{
    print("Соединение установлено");
}

$sql = "SELECT id, name FROM categories";
$result = mysqli_query($mysql, $sql);

$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

foreach($rows as $row){
    print("Категории: " . $row['name']);
}