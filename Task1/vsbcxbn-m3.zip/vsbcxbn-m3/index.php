<?php
require_once ('helpers.php');
require_once ('init.php');

$main = include_template('main.php', [
        'categories' => get_categories_list($mysql),
        'lots' => get_lot_list($mysql)
]);

$layout_content = include_template('layout.php',[
    'main' => $main,
    'user_name' => $user_name,
    'categories' => get_lot_list($mysql),
    'title' => 'Главная',
    'is_auth' => $is_auth,
]);
print($layout_content);
?>