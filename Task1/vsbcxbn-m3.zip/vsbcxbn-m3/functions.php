<?php
    function format( int $num): string{
        return number_format($num, 0, '', ' '). '&#8381;';
    }

const SECOND_PER_HOUR = 3600;
const MINUTES_PER_HOUR = 60;

    function get_dt_range(string $date): array{

        $date_dif = strtotime($date) - time();

        $hours = str_pad(floor(($date_dif) / SECOND_PER_HOUR), 2, "0", STR_PAD_LEFT);
        $minutes = str_pad((ceil(($date_dif) / MINUTES_PER_HOUR) % MINUTES_PER_HOUR) , 2, "0", STR_PAD_LEFT);
        return [$hours, $minutes];
    }

    function get_categories_list($mysql){
        $sql_query = "SELECT name FROM category";
        $result = mysqli_query($mysql, $sql_query);
        $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $rows;
    }

    function get_lot_list($mysql){
        $sql_query = "SELECT 'lot' ,*, 'category', 'name' AS 'category_name' FROM 'lot' inner join 'category' ON 'lot'.'category_id' = 'category'.'id'";
        $result = mysqli_query($mysql, $sql_query);
        $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $rows;
    }

?>