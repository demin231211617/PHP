#Очищение таблицы
delete from bid;
delete from lot;
delete from user;
delete from category;

#Установление авто-инкримента
alter table bid AUTO_INCREMENT = 1;
alter table lot AUTO_INCREMENT = 1;
alter table user AUTO_INCREMENT = 1;
alter table category AUTO_INCREMENT = 1;
# Добавление катергорий
insert into category(name, code)
values
    ("Доски и лыжи", "boards"),
    ("Крепления", "attachment"),
    ("Ботинки", "boots"),
    ("Одежда", "clothing"),
    ("Инструменты","tools"),
    ("Разное", "other");
#Добавление пользователя
insert into user(email, name, password, contacts)
values
    ("demin@gmail.com", "Auther", "1234", "+79961457896"),
    ("merin@gmail.com", "Marina", "1234", "+79961457886");
#Добавление лота
insert into lot(name, description, image, start_price, date_finish, step_bid, author_id, winner_id, category_id)
values
    ("2014 Rossignol District Snowboard", NULL, "img/lot-1.jpg", 10999,"2023-09-14", 10, 1,2,1),
    ("DC Ply Mens 2016/2017 Snowboard", NULL, "img/lot-2.jpg", 159999,"2023-09-13", 10,1 2,1),
    ("Крепления Union Contact Pro 2015 года размер L/XL", NULL, "img/lot-3.jpg", 8000,"2023-09-21", 10, 1, NULL, 2),
    ("Ботинки для сноуборда DC Mutiny Charocal", NULL, "img/lot-4.jpg", 10999,"2023-09-18", 10, 1, null, 3),
    ("Куртка для сноуборда DC Mutiny Charocal", NULL, "img/lot-5.jpg", 7500,"2023-09-17", 10, 1, null, 4),
    ("Маска Oakley Canopy", NULL, "img/lot-6.jpg", 5400,"2023-09-18", 10, 1, null, 6);

#Добавление ставок
insert into bid(price, user_id, lot_id)
values
    (200000,2,2),
    (15000,2,1);

#получение всех категорий
select from category;

#получить cписок лотов, которые еще не истекли отсортированных по дате публикации, от новых к старым.
#Каждый лот должен включать название, стартовую цену, ссылку на изображение, название категории и дату окончания торгов;

select l.name, l.start_price, l.image, c.name as category, l.date_finish from lot as l
inner join categoy as c on l.category_id = c.id
where l.date_finish > CURRENT_DATE
order by l.create_date DESC;

# показать информацию о лоте по его ID. Вместо id категории должно выводиться  название категории, к которой принадлежит лот из таблицы категорий
select l.id, l.create_date, l.name, l.description, l.image, l.start_price, l.date_finish, l.step_bid, c.name from lot as l
inner join  category as c on l.category_id = c.id
where l.id = @;

#обновить название лота по его идентификатору
update lot
set name = @
where id = @;

#Получить список ставок для лота по его индефикатору с сортировкой по дате. Список должен
#содержать дату и время размещения ставки, цену, по которой пользователь готов приобрести лот,
#название лота и имя пользователя, сделавшего ставку

select r.create_date, r.price, l.name, u.name from bid as r
inner join  lot as l on r.lot_id = l.id
inner join user as u on r.user_id = u.id
where r.lot_id = @
order by r.create_date