<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?=$lot['name']?></title>
    <link href="../css/normalize.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>

<div class="page-wrapper">

    <header class="main-header">
        <div class="main-header__container container">
            <h1 class="visually-hidden">YetiCave</h1>
            <a class="main-header__logo" href="index.html">
                <img src="../img/logo.svg" width="160" height="39" alt="Логотип компании YetiCave">
            </a>
            <form class="main-header__search" method="get" action="https://echo.htmlacademy.ru" autocomplete="off">
                <input type="search" name="search" placeholder="Поиск лота">
                <input class="main-header__search-btn" type="submit" name="find" value="Найти">
            </form>
            <a class="main-header__add-lot button" href="add-lot.html">Добавить лот</a>
            <nav class="user-menu">
                <ul class="user-menu__list">
                    <li class="user-menu__item">
                        <a href="sign-up.html">Регистрация</a>
                    </li>
                    <li class="user-menu__item">
                        <a href="login.html">Вход</a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <nav class="nav">
            <ul class="nav__list container">
                <li class="nav__item">
                    <a href="all-lots.html">Доски и лыжи</a>
                </li>
                <li class="nav__item">
                    <a href="all-lots.html">Крепления</a>
                </li>
                <li class="nav__item">
                    <a href="all-lots.html">Ботинки</a>
                </li>
                <li class="nav__item">
                    <a href="all-lots.html">Одежда</a>
                </li>
                <li class="nav__item">
                    <a href="all-lots.html">Инструменты</a>
                </li>
                <li class="nav__item">
                    <a href="all-lots.html">Разное</a>
                </li>
            </ul>
        </nav>
        <section class="lot-item container">
            <h2><?=$lots['name_lot']?></h2>
            <div class="lot-item__content">
                <div class="lot-item__left">
                    <div class="lot-item__image">
                        <img src="<?=$lots['picture']?>" width="730" height="548" alt="">
                    </div>
                    <p class="lot-item__category">Категория: <span><?=$lots['name']?></span></p>
                    <p class="lot-item__description"><?=$lots['description']?></p>
                </div>
                <div class="lot-item__right">
                    <div class="lot-item__state">
                            <?php if(get_dt_range($lots['date_end'])[0] < 24):?>
                                <div class="lot-item__timer timer timer--finishing">
                                    <?= sprintf("%s:%s",get_dt_range($lots['date_end'])[0],get_dt_range($lots['date_end'])[1])?>
                                </div>
                            <?php else:?>
                                <div class="lot-item__timer timer">
                                    <?= sprintf("%s:%s",get_dt_range($lots['date_end'])[0],get_dt_range($lots['date_end'])[1])?>
                                </div>
                            <?php endif;?>

                        <div class="lot-item__cost-state">
                            <div class="lot-item__rate">
                                <span class="lot-item__amount">Текущая цена</span>
                                <span class="lot-item__cost"><?=$lots['start_price']?></span>
                            </div>
                            <div class="lot-item__min-cost">
                                Мин. ставка <span>12 000 р</span>
                            </div>
                        </div>
                        <form class="lot-item__form" action="https://echo.htmlacademy.ru" method="post" autocomplete="off">
                            <p class="lot-item__form-item form__item form__item--invalid">
                                <label for="cost">Ваша ставка</label>
                                <input id="cost" type="text" name="cost" placeholder="12 000">
                                <span class="form__error">Введите наименование лота</span>
                            </p>
                            <button type="submit" class="button">Сделать ставку</button>
                        </form>
                    </div>
                    <div class="history">
                        <h3>История ставок (<span>10</span>)</h3>
                        <table class="history__list">
                            <tr class="history__item">
                                <td class="history__name">Иван</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">5 минут назад</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Константин</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">20 минут назад</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Евгений</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">Час назад</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Игорь</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">19.03.17 в 08:21</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Енакентий</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">19.03.17 в 13:20</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Семён</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">19.03.17 в 12:20</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Илья</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">19.03.17 в 10:20</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Енакентий</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">19.03.17 в 13:20</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Семён</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">19.03.17 в 12:20</td>
                            </tr>
                            <tr class="history__item">
                                <td class="history__name">Илья</td>
                                <td class="history__price">10 999 р</td>
                                <td class="history__time">19.03.17 в 10:20</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>

</div>

<footer class="main-footer">
    <nav class="nav">
        <ul class="nav__list container">
            <li class="nav__item">
                <a href="all-lots.html">Доски и лыжи</a>
            </li>
            <li class="nav__item">
                <a href="all-lots.html">Крепления</a>
            </li>
            <li class="nav__item">
                <a href="all-lots.html">Ботинки</a>
            </li>
            <li class="nav__item">
                <a href="all-lots.html">Одежда</a>
            </li>
            <li class="nav__item">
                <a href="all-lots.html">Инструменты</a>
            </li>
            <li class="nav__item">
                <a href="all-lots.html">Разное</a>
            </li>
        </ul>
    </nav>
    <div class="main-footer__bottom container">
        <div class="main-footer__copyright">
            <p>© 2019, YetiCave</p>
            <p>Интернет-аукцион сноубордического и горнолыжного снаряжения</p>
        </div>
        <div class="main-footer__social social">
            <span class="visually-hidden">Мы в соцсетях:</span>
            <a class="social__link social__link--facebook" href="#">
                <span class="visually-hidden">Facebook</span>
                <svg width="27" height="27" viewBox="0 0 27 27" xmlns="http://www.w3.org/2000/svg"><circle stroke="#879296" fill="none" cx="13.5" cy="13.5" r="12.667"/><path fill="#879296" d="M14.26 20.983h-2.816v-6.626H10.04v-2.28h1.404v-1.364c0-1.862.79-2.922 3.04-2.922h1.87v2.28h-1.17c-.876 0-.972.322-.972.916v1.14h2.212l-.245 2.28h-1.92v6.625z"/></svg>
            </a>
            <span class="visually-hidden">,</span>
            <a class="social__link social__link--twitter" href="#">
                <span class="visually-hidden">Twitter</span>
                <svg width="27" height="27" viewBox="0 0 27 27" xmlns="http://www.w3.org/2000/svg"><circle stroke="#879296" fill="none" cx="13.5" cy="13.5" r="12.687"/><path fill="#879296" d="M18.38 10.572c.525-.336.913-.848 1.092-1.445-.485.305-1.02.52-1.58.635-.458-.525-1.12-.827-1.816-.83-1.388.063-2.473 1.226-2.44 2.615-.002.2.02.4.06.596-2.017-.144-3.87-1.16-5.076-2.78-.22.403-.335.856-.332 1.315-.01.865.403 1.68 1.104 2.188-.397-.016-.782-.13-1.123-.333-.03 1.207.78 2.272 1.95 2.567-.21.06-.43.09-.653.088-.155.015-.313.015-.47 0 .3 1.045 1.238 1.777 2.324 1.815-.864.724-1.956 1.12-3.083 1.122-.198.013-.397.013-.595 0 1.12.767 2.447 1.18 3.805 1.182 4.57 0 7.066-3.992 7.066-7.456v-.34c.49-.375.912-.835 1.24-1.357-.465.218-.963.36-1.473.42z"/></svg>
            </a>
            <span class="visually-hidden">,</span>
            <a class="social__link social__link--instagram" href="#">
                <span class="visually-hidden">Instagram</span>
                <svg width="27" height="27" viewBox="0 0 27 27" xmlns="http://www.w3.org/2000/svg"><circle stroke="#879296" fill="none" cx="13.5" cy="13.5" r="12.687"/><path fill="#879296" d="M13.5 8.3h2.567c.403.002.803.075 1.18.213.552.213.988.65 1.2 1.2.14.38.213.778.216 1.18v5.136c-.003.403-.076.803-.215 1.18-.213.552-.65.988-1.2 1.2-.378.14-.778.213-1.18.216h-5.135c-.403-.003-.802-.076-1.18-.215-.552-.214-.988-.65-1.2-1.2-.14-.38-.212-.78-.215-1.182V13.46v-2.566c.003-.403.076-.802.214-1.18.213-.552.65-.988 1.2-1.2.38-.14.778-.212 1.18-.215H13.5m0-1.143h-2.616c-.526.01-1.048.108-1.54.292-.853.33-1.527 1-1.856 1.854-.184.493-.283 1.014-.292 1.542v5.232c.01.526.108 1.048.292 1.54.33.853 1.003 1.527 1.855 1.856.493.184 1.015.283 1.54.293H16.117c.527-.01 1.048-.11 1.54-.293.854-.33 1.527-1.003 1.856-1.855.184-.493.283-1.015.293-1.54V13.46v-2.614c-.01-.528-.11-1.05-.293-1.542-.33-.853-1.002-1.525-1.855-1.855-.493-.185-1.014-.283-1.54-.293-.665.01-.89 0-2.617 0zm0 3.093c-2.51.007-4.07 2.73-2.808 4.898 1.26 2.17 4.398 2.16 5.645-.017.285-.495.434-1.058.433-1.63-.006-1.8-1.47-3.256-3.27-3.25zm0 5.378c-1.63-.007-2.64-1.777-1.82-3.185.823-1.41 2.86-1.4 3.67.017.18.316.276.675.278 1.04.006 1.177-.95 2.133-2.128 2.128zm4.118-5.524c0 .58-.626.94-1.127.65-.5-.29-.5-1.012 0-1.3.116-.067.245-.102.378-.102.418-.005.76.333.76.752z"/></svg>
            </a>
            <span class="visually-hidden">,</span>
            <a class="social__link social__link--vkontakte" href="#">
                <span class="visually-hidden">Вконтакте</span>
                <svg width="27" height="27" viewBox="0 0 27 27" xmlns="http://www.w3.org/2000/svg"><circle stroke="#879296" fill="none" cx="13.5" cy="13.5" r="12.666"/><path fill="#879296" d="M13.92 18.07c.142-.016.278-.074.39-.166.077-.107.118-.237.116-.37 0 0 0-1.13.516-1.296.517-.165 1.208 1.09 1.95 1.58.276.213.624.314.973.28h1.95s.973-.057.525-.837c-.38-.62-.865-1.17-1.432-1.626-1.208-1.1-1.043-.916.41-2.816.886-1.16 1.236-1.86 1.13-2.163-.108-.302-.76-.214-.76-.214h-2.164c-.092-.026-.19-.026-.282 0-.083.058-.15.135-.195.225-.224.57-.49 1.125-.8 1.656-.973 1.61-1.344 1.697-1.51 1.59-.37-.234-.272-.975-.272-1.433 0-1.56.243-2.202-.468-2.377-.32-.075-.647-.108-.974-.098-.604-.052-1.213.01-1.793.186-.243.116-.438.38-.32.4.245.018.474.13.642.31.152.303.225.638.214.975 0 0 .127 1.832-.302 2.056-.43.223-.692-.167-1.55-1.618-.29-.506-.547-1.03-.77-1.57-.038-.09-.098-.17-.174-.233-.1-.065-.214-.108-.332-.128H6.485s-.312 0-.42.137c-.106.135 0 .36 0 .36.87 2 2.022 3.868 3.42 5.543.923.996 2.21 1.573 3.567 1.598z"/></svg>
            </a>
        </div>
        <a class="main-footer__add-lot button" href="add-lot.html">Добавить лот</a>
        <div class="main-footer__developed-by">
            <span class="visually-hidden">Разработано:</span>
            <a class="logo-academy" href="https://htmlacademy.ru/intensive/php">
                <span class="visually-hidden">HTML Academy</span>
                <svg width="118" height="40" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 117.01 40">
                    <path fill="#879296"
                          d="M280.33,109.39a2.14,2.14,0,0,1-.6.11.59.59,0,0,1-.66-.66v-3.24c0-2.73-1.62-4-4.18-4a11.08,11.08,0,0,0-3.47.6v1.85a8.05,8.05,0,0,1,3.26-.7c1.54,0,2.37.79,2.37,1.92v.32a12,12,0,0,0-2.36-.26c-1.88,0-4,.72-4,3,0,1.87,1.53,2.77,3.17,2.77a5.25,5.25,0,0,0,3.41-1.17,1.81,1.81,0,0,0,1.81,1.06,3.52,3.52,0,0,0,1.28-.23v-1.45Zm-3.28-.85a3.68,3.68,0,0,1-2.62,1.07c-.9,0-1.7-.45-1.7-1.34,0-1.13,1.21-1.49,2.36-1.49a10.56,10.56,0,0,1,2,.23v1.53Zm9,2.64a6.81,6.81,0,0,0,3-.62V108.7a5.44,5.44,0,0,1-2.64.7,3,3,0,1,1,0-6,4.42,4.42,0,0,1,2.51.75v-1.85a5.47,5.47,0,0,0-2.79-.7,4.69,4.69,0,0,0-5,4.84,4.57,4.57,0,0,0,4.88,4.69Zm8.29-5.8c-1.88,0-4,.72-4,3,0,1.87,1.53,2.77,3.17,2.77a5.25,5.25,0,0,0,3.41-1.17,1.81,1.81,0,0,0,1.81,1.05,3.54,3.54,0,0,0,1.28-.23v-1.45a2.13,2.13,0,0,1-.6.11.59.59,0,0,1-.66-.66v-3.24c0-2.73-1.62-4-4.18-4a11.08,11.08,0,0,0-3.47.6v1.85a8.05,8.05,0,0,1,3.26-.7c1.55,0,2.37.79,2.37,1.92v.32a12,12,0,0,0-2.36-.26Zm2.36,3.17a3.68,3.68,0,0,1-2.62,1.07c-.9,0-1.7-.45-1.7-1.34,0-1.13,1.21-1.49,2.36-1.49a10.56,10.56,0,0,1,2,.23v1.53Zm4.11-2.13a4.49,4.49,0,0,0,4.48,4.77,4.21,4.21,0,0,0,3.47-1.68v1.43h1.81V97.75h-2v5.31a4.19,4.19,0,0,0-3.26-1.41,4.49,4.49,0,0,0-4.48,4.77Zm7.73-1.11v2.2a3.15,3.15,0,0,1-2.88,1.9,3,3,0,0,1,0-6,3.16,3.16,0,0,1,2.88,1.88Zm9.12,5.88a7.75,7.75,0,0,0,3.24-.62v-1.73a6.62,6.62,0,0,1-2.86.64c-1.66,0-3.24-.68-3.47-2.3h6.8c.58-2.62-.66-5.52-4.26-5.52a4.53,4.53,0,0,0-4.58,4.77c0,3.18,2.36,4.77,5.13,4.77Zm-.45-7.86a2.13,2.13,0,0,1,2.36,2.34h-5a2.47,2.47,0,0,1,2.66-2.34Zm18.43,2v5.6h2v-5.65a3.32,3.32,0,0,0-3.43-3.64A4.48,4.48,0,0,0,331,103.1a3.09,3.09,0,0,0-2.83-1.45,4.13,4.13,0,0,0-3,1.38v-1.13h-1.79v9h2v-6.11a3.21,3.21,0,0,1,2.39-1.39,1.72,1.72,0,0,1,1.79,1.9v5.6h2v-5.65c0-.21,0-.41,0-.62a3,3,0,0,1,2.24-1.22,1.72,1.72,0,0,1,1.79,1.9Zm13-3.45h-2.11l-2.69,6.82-3.05-6.82h-2.15l4.3,9.12-.19.45c-.53,1.41-1.26,2.11-2.24,2.11a3.13,3.13,0,0,1-.92-.13v1.71a5.12,5.12,0,0,0,1.19.15c1.38,0,2.66-.79,3.64-3.15l4.24-10.27ZM273.33,89.11a3.18,3.18,0,0,1,2.53-1.51A2,2,0,0,1,278,89.77V95.1h2v-5.6a3.52,3.52,0,0,0-3.73-3.69,4.12,4.12,0,0,0-2.92,1.24V81.91h-2V95.1h2v-6Zm10.18,3.24c0,2.11,1.36,3,3.11,3a7.39,7.39,0,0,0,2.43-.4V93.2a4.87,4.87,0,0,1-1.83.36c-1.17,0-1.72-.4-1.72-1.58V87.83h3.28V86.06h-3.28V82.84l-2,.49v2.73h-1.62v1.77h1.62v4.52ZM293.38,89a3.21,3.21,0,0,1,2.39-1.39,1.72,1.72,0,0,1,1.79,1.9v5.6h2V89.45c0-.21,0-.41,0-.62a3,3,0,0,1,2.24-1.22,1.72,1.72,0,0,1,1.79,1.9v5.6h2V89.45a3.32,3.32,0,0,0-3.43-3.64A4.47,4.47,0,0,0,299,87.26a3.09,3.09,0,0,0-2.83-1.45,4.13,4.13,0,0,0-3,1.38V86.06h-1.79v9h2V89Zm15.16-7.09h2V95.1h-2Zm-61.11-1.57L231.64,82v28.95l15.79,9.4,15.79-9.4V82L247.6,80.35l-.17,0Zm13.73,29.43-13.73,8.17-13.73-8.17V97.9L247.37,106l0,1.47L238,101.93v1.43l9.41,5.66,0,1.51-9.41-5.6v1.43l9.41,5.66,9.5-5.69V104.9h0v-4.67l4.23-2.53v12.06Zm0-13.6-3.76,2.21-1.73,1-8.27-4.92v1.43l7.07,4.2-.06,0-.15.09-1,.59-5.83-3.47v1.43l4.61,2.74-1.09.73,0,0-3.48-2v1.43l2.28,1.34-2.33,1.4-13.6-8.08,13.62-8.19h0l13.79,8Zm0-1.44-13.8-8.14h0l-13.65,8.13V83.85l13.73-1.44,13.73,1.44V94.72Z"
                          transform="translate(-231.64 -80.34)"/>
                </svg>
            </a>
        </div>
    </div>
</footer>

</body>
</html>