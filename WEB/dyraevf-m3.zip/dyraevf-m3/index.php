<?php
    require_once ('helpers.php');
    require_once ('functions.php');
    require_once ('init.php');

    $main = include_template('main.php', [
        'lots' => lot_list($con),
        'categories' => category_list($con),
    ]);

    print($layout = include_template('layout.php', [
        'is_auth' => $is_auth,
        'user_name' => $user_name,
        'title' => $title,
        'categories' => category_list($con),
        'lots' => lot_list($con),
        'main' => $main
    ]));
?>