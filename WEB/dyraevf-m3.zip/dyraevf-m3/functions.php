<?php
function format(int $num): string{
    return number_format($num, 0, '', ' '). ' ₽';
}

const SECOND_PER_HOUR = 3600;
const MINUTES_PER_HOUR = 60;

function get_dt_range(string $date_end): array{
    $date_dif = strtotime($date_end) - time();
    $hours = str_pad(floor(($date_dif) / SECOND_PER_HOUR), 2, "0", STR_PAD_LEFT);
    $minutes = str_pad((ceil(($date_dif) / MINUTES_PER_HOUR) % MINUTES_PER_HOUR) , 2, "0", STR_PAD_LEFT);
    return [$hours, $minutes];
}

function lot_list(mysqli $con):array{
    $sql = "SELECT Lot.id,  Lot.name as name_lot, picture, start_price, date_end, Category.name FROM Lot
    INNER JOIN Category ON Lot.category_id = Category.id
    WHERE date_end > NOW() ORDER BY date_reg DESC";

    return mysqli_fetch_all(mysqli_query($con, $sql), MYSQLI_ASSOC);
}

function category_list(mysqli $con):array{
    $sql = "SELECT name, sym_code FROM Category";

    return mysqli_fetch_all(mysqli_query($con, $sql), MYSQLI_ASSOC);
}

function lot_detail(mysqli $con, int $id_lot):array{
    $sql = "SELECT Lot.name as name_lot, picture, start_price, date_end, Category.name FROM Lot
    INNER JOIN Category ON Lot.category_id = Category.id 
    WHERE Lot.id = ? ";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $id_lot);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $rows = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $rows;
}


?>